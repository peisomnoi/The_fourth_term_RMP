package com.example.mydialer

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import java.net.HttpURLConnection
import java.net.URL

class FragmentContact : Fragment() {
    var contacts = arrayListOf<Contact>()
    var contactsJson = arrayListOf<Contact>()
    val adapter = ListAdapter()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_contact, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val recycleView: RecyclerView = requireView().findViewById(R.id.rView)
        val data = "https://drive.google.com/u/0/uc?id=1-KO-9GA3NzSgIc1dkAsNm8Dqw0fuPxcR&export=download"
        Thread {
            val connection = URL(data).openConnection() as HttpURLConnection
            val jsonData = connection.inputStream.bufferedReader().readText()

            contactsJson = Gson().fromJson(jsonData, Array<Contact>::class.java).toList() as ArrayList<Contact>
            contacts = contactsJson.clone() as ArrayList<Contact>
            requireActivity().runOnUiThread {
                recycleView.layoutManager = LinearLayoutManager(this.context)
                recycleView.adapter = adapter
                adapter.submitList(contactsJson)
                adapter.notifyDataSetChanged()
            }
            val et_search: EditText = view.findViewById(R.id.et_search)!!
            et_search.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable) {
                }
                override fun beforeTextChanged(
                    s: CharSequence, start: Int,
                    count: Int, after: Int
                ) {}
                override fun onTextChanged(
                    s: CharSequence, start: Int,
                    before: Int, count: Int
                ) {
                    search()
                }
            })
        }.start()
    }
    fun search() {
        val et_search: EditText = view?.findViewById(R.id.et_search)!!
        contacts.clear()
        if (!et_search.text.isNullOrBlank()) {
            for (contact in contactsJson) {
                if ((contact.name.contains(et_search.text)) or
                    (contact.phone.contains(et_search.text)) or
                    (contact.type.contains(et_search.text))
                )
                    contacts.add(contact)
            }
        } else {
            contacts = contactsJson.clone() as ArrayList<Contact>
        }
        adapter.submitList(contacts)
        adapter.notifyDataSetChanged()
    }
}

data class Contact(
    val name: String,
    val phone: String,
    val type: String
)

class ContactItemDiffCallback : DiffUtil.ItemCallback<Contact>(){
    override fun areItemsTheSame(oldItem: Contact, newItem: Contact) = oldItem == newItem
    override fun areContentsTheSame(oldItem: Contact, newItem: Contact) = oldItem == newItem
}

class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val textview1: TextView = view.findViewById(R.id.textView)
    val textview2: TextView = view.findViewById(R.id.textView2)
    val textview3: TextView = view.findViewById(R.id.textView3)

    fun bindTo(contact: Contact){
        if (textview1 != null) {textview1.text = contact.name}
        if (textview2 != null) {textview2.text = contact.phone}
        if (textview3 != null) {textview3.text = contact.type}
    }
}

class ListAdapter : androidx.recyclerview.widget.ListAdapter<Contact, ViewHolder>(ContactItemDiffCallback()){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.rview_item, parent, false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = currentList[position]
        holder.bindTo(data)
    }
}