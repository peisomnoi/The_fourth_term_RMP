package com.example.retrofitforecaster

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var mService: RetrofitServices
    lateinit var layoutManager: LinearLayoutManager
    val adapter = Adapter()
    var listweather = listOf<ListItem>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val recyclerView: RecyclerView = findViewById(R.id.rView)
        title = "Krasnodar"
        mService = Common.retrofitService
        layoutManager = LinearLayoutManager(this)
        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter
        getAllWeatherList("Krasnodar")
    }
    fun getAllWeatherList(city: String) {
        mService.getWeatherList(city).enqueue(object : Callback<DataWeather> {
            override fun onResponse(call: Call<DataWeather>, response: Response<DataWeather>) {
                val abc = response.body() as DataWeather
                listweather = abc.list
                Log.d("REQUEST_OK", abc.cod)
                adapter.submitList(listweather)
                adapter.notifyDataSetChanged()
            }
            override fun onFailure(call: Call<DataWeather>, t: Throwable) {
                Log.d("FAIL", t.message.toString())
            }
        })
    }
}