package com.example.retrofitforecaster

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


object RetrofitClient{
    fun getClient(): Retrofit {

        val logger = HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)

        logger.redactHeader("Authorization")
        logger.redactHeader("Cookie")

        val okHttp = OkHttpClient.Builder().addInterceptor(logger)

        val builder = Retrofit
            .Builder()
            .baseUrl(Common.BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .client(okHttp.build())

        return builder.build()
    }
}



